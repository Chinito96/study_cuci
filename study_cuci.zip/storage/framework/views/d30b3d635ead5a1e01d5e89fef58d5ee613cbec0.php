<footer class="footer pt-10 mt-auto bg-light footer-light fixed-bottom bg-gray-800 text-gray-300">
    <div class="py-4 font-weight-light">
        <div class="container">
            <div class="align-items-center row">
                <div class="text-center text-md-left col-md-6">
                    <p class="text-sm mb-md-0">© 2020, STUDY CUCI.  Todos los derechos reservados.</p>
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\IT\Documents\study_cuci\resources\views/layouts/footer.blade.php ENDPATH**/ ?>