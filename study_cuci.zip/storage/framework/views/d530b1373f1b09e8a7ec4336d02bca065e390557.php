
<?php $__env->startSection('head-code'); ?>
<style>
    main {
        background: #009bff;
        background: -webkit-linear-gradient(left, #0072ff, #00c6ff);
        background: -o-linear-gradient(left, #0072ff, #00c6ff);
        background: -moz-linear-gradient(left, #0072ff, #00c6ff);
        background: linear-gradient(left, #0072ff, #00c6ff); 
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="contact1">
    <?php if(session()->get('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    <div class="container-contact1">
        <div class="contact1-pic js-tilt" data-tilt=""
            style="transform: perspective(300px) rotateX(0deg) rotateY(0deg); will-change: transform;">
            <img src="<?php echo e(asset('img/img-01.png')); ?>" alt="IMG">
        </div>
        <form method="POST" action="<?php echo e(url('contact-us')); ?>" class="contact1-form validate-form">
            <?php echo csrf_field(); ?>
            <span class="contact1-form-title">
                Queremos escucharte
            </span>
            <div class="wrap-input1 validate-input" data-validate="Name is required">
                <input class="input1 form-control" type="text" name="name" placeholder="Nombre">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <span class="shadow-input1"></span>
            </div>
            <div class="wrap-input1 validate-input" data-validate="Valid email is required: ex@abc.xyz">
                <input class="input1 form-control" type="text" name="email" placeholder="Correo">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <span class="shadow-input1"></span>
            </div>
            <div class="wrap-input1 validate-input" data-validate="Subject is required">
                <input class="input1 form-control" type="text" name="subject" placeholder="Asunto">
                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <span class="shadow-input1"></span>
            </div>
            <div class="wrap-input1 validate-input" data-validate="Message is required">
                <textarea class="input1 form-control" rows="4" cols="4" name="message" placeholder="Mensaje"></textarea>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <span class="shadow-input1"></span>
            </div>
            <div class="container-contact1-form-btn">
                <button type="submit" class="contact1-form-btn btn btn-success">
                    <span>
                        Enviar Email
                        <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT\Documents\study_cuci\resources\views/contact.blade.php ENDPATH**/ ?>