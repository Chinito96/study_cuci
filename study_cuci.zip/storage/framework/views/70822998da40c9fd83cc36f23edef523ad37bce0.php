
<?php $__env->startSection('content'); ?>
<section>
    <div class="container">
        <div class="row">

        </div>
        <div class="table-responsive">
            <table id="ap_table" class="table-striped responsive nowrap dataTable" style="width: 100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Usuario</th>
                        <th>Domicilio Cuarto</th>
                        <th>Contacto Cuarto</th>
                        <th>Contacto Usuario</th>
                        <th>Estatus</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($appointment['id']); ?>">
                        <td><?php echo e($appointment['id']); ?></td>
                        <td><?php echo e($appointment['username']); ?></td>
                        <td><?php echo e($appointment['address']); ?></td>
                        <td><?php echo e($appointment['room_contact']); ?></td>
                        <td><?php echo e($appointment['phone']); ?></td>
                        <td><?php echo e($appointment['status']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
<script>
$(document).ready(function(){
    let ap = $('#ap_table').DataTable({
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.childRowImmediate,
                type: 'none',
                target: ''
            }
        },
        dom: 'lBfrtip',
        select: {
            style: 'single'
        },
        buttons: [
            {
                text: 'Cambiar Estatus',
                className: 'btn btn-success mx-3',
                action: function(e, dt, node, config) {
                    let id = dt.row({selected: true}).id();
                    alert(id);
                },
                init: function(api, node, config) {
                    $(node).removeClass('dt-button');
                },
                enabled: false
            }
        ]
    });
    ap.on('select deselect', function () {
        let selectedRow = ap.rows({ selected: true}).count();
        ap.button(0).enable(selectedRow === 1);
    });
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT\Documents\study_cuci\resources\views/dashboard.blade.php ENDPATH**/ ?>