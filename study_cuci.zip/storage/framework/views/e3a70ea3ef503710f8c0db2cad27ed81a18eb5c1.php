
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <?php if(session()->get('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    <?php if(session()->get('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session()->get('error')); ?>

    </div>
    <?php endif; ?>
    <div class="row">
    <?php
        $room = 0;
    ?>
    <?php $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
      <div class="card mb-4 shadow-sm">
        <div data-toggle="modal" data-target="#galleryModal">
          <img class="bd-placeholder-img card-img-top" width="100%" height="225" src="<?php echo e(asset('img/casas/'.$habitacion->imagen)); ?>" alt="" data-target="#carouselGallery" data-slide-to="<?php echo e($room); ?>"/>
        </div>
        <div class="card-body">
          <p class="card-text"><?php echo e($habitacion->descripcion); ?></p>
          <div class="d-flex justify-content-between align-items-center">
            <div class="btn-group">
              <button data-room="<?php echo e($habitacion->id); ?>" data-address="<?php echo e($habitacion->domicilio); ?>" class="appointment btn btn-sm btn-outline-success">Quiero una cita</button>
            </div>
            <span <?php if($habitacion->genero == "Femenino"): ?>
            class="badge badge-danger text-center"
            <?php elseif($habitacion->genero == "Masculino"): ?>
            class="badge badge-primary text-center"    
            <?php else: ?>
            class="badge badge-secondary text-center"
            <?php endif; ?>>
              <?php echo e($habitacion->genero); ?>

            </span>
            <small class="text-muted">$<?php echo e($habitacion->precio); ?></small>
          </div>
        </div>
      </div>
    </div>
    <?php
        $room = $room + 1;
    ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<!-- Gallery -->
<div class="modal fade" id="galleryModal" tabindex="-1" role="dialog" aria-labelledby="galleryModal" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <!-- Carousel -->
        <div id="carouselGallery" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <?php
                $count = 0;
            ?>
          <?php $__currentLoopData = $habitaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($count == 0): ?>
            <div class="carousel-item active">    
            <?php else: ?>
            <div class="carousel-item">    
            <?php endif; ?>
              <img class="d-block w-100" src="<?php echo e(asset('img/casas/'.$habitacion->imagen)); ?>" alt="">
            </div>
            <?php
            $count = $count + 1;
            ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          <a class="carousel-control-prev" href="#carouselGallery" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Anterior</span>
          </a>
          <a class="carousel-control-next" href="#carouselGallery" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Siguiente</span>
          </a>

        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
</div>
<?php echo $__env->make('modals.room', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
<script>
$(document).ready(function(){

  $('.appointment').click(function() {
    let id = $(this).data("room");
    let address = $(this).data("address");
    $('#room_id').val(id);
    $('#room_address').text(address);
    $('#room-event').modal('show');
  });

})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT\Documents\study_cuci\resources\views/habitaciones.blade.php ENDPATH**/ ?>