<h2>Hello Admin,</h2>
<p>You received an email from : <b><?php echo e($name); ?></b></p>
<h3>Here are the details:</h3>
<p><b>Name:</b> <?php echo e($name); ?></p>
<p><b>Email:</b> <?php echo e($email); ?></p>
<p><b>Subject:</b> <?php echo e($subject); ?></p>
<p><b>Message:</b> <?php echo e($user_message); ?></p>
Thank You<?php /**PATH C:\Users\IT\Documents\study_cuci\resources\views/emails/contact.blade.php ENDPATH**/ ?>