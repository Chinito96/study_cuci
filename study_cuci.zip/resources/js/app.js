require('./bootstrap');

import $ from 'jquery';
window.$ = window.jQuery = $;