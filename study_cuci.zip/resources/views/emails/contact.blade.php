<h2>Hello Admin,</h2>
<p>You received an email from : <b>{{ $name }}</b></p>
<h3>Here are the details:</h3>
<p><b>Name:</b> {{ $name }}</p>
<p><b>Email:</b> {{ $email }}</p>
<p><b>Subject:</b> {{ $subject }}</p>
<p><b>Message:</b> {{ $user_message }}</p>
Thank You